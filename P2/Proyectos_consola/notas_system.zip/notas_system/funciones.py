class Func():
  @staticmethod
  def borrarPantalla():
    import os  
    os.system("cls")
    
  @staticmethod
  def esperarTecla():
    print("\n \t \tOprima cualquier tecla para continuar ...")
    input()  